package uniandes.dpoo.aerolinea.persistencia;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.nio.file.Files;

import org.json.JSONArray;
import org.json.JSONObject;

import uniandes.dpoo.aerolinea.exceptions.AvionRepetidoException;
import uniandes.dpoo.aerolinea.exceptions.RutaRepetidaException;
import uniandes.dpoo.aerolinea.exceptions.VueloRepetidoException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Avion;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;

public class PersistenciaAerolineaJson implements IPersistenciaAerolinea{
	
	private static final String NOMBRE_AVION = "nombreAvion";
	private static final String CAPCIDAD_AVION = "capacidadAvion";
	private static final String RUTA_HSALIDA = "rutaHSalida";
	private static final String RUTA_HLLEGADA = "rutaHLlegada";
	private static final String CODIGO_RUTA = "codigoRuta";
	private static final String AEROPUERTOO_NOMBRE = "aeropuertoONombre";
	private static final String AEROPUERTOO_CODIGO = "aeropuertoOCodigo";
	private static final String AEROPUERTOO_CIUDAD = "aeropuertoOCiudad";
	private static final String AEROPUERTOO_LATITUD = "aeropuertoOLatitud";
	private static final String AEROPUERTOO_LONGITUD = "aeropuertoOLongitud";
	private static final String AEROPUERTOD_NOMBRE = "aeropuertoDNombre";
	private static final String AEROPUERTOD_CODIGO = "aeropuertoDCodigo";
	private static final String AEROPUERTOD_CIUDAD = "aeropuertoDCiudad";
	private static final String AEROPUERTOD_LATITUD = "aeropuertoDLatitud";
	private static final String AEROPUERTOD_LONGITUD = "aeropuertoDLongitud";
	private static final String FECHA = "fecha";
	
	
	
	@Override
	public void cargarAerolinea( String archivo, Aerolinea aerolinea ) throws Exception
    {
		String jsonCompleto = new String( Files.readAllBytes( new File( archivo ).toPath( ) ) );
        JSONObject raiz = new JSONObject( jsonCompleto );
        
        cargarAviones( aerolinea, raiz.getJSONArray( "aviones" ) );
        cargarRutas( aerolinea, raiz.getJSONArray( "ruta" ) );
        cargarVuelos( aerolinea, raiz.getJSONArray( "vuelo" ) );
		
    }

    @Override
    public void salvarAerolinea( String archivo, Aerolinea aerolinea ) throws FileNotFoundException
    {

		JSONObject jobject = new JSONObject();
		
		//Aviones
		salvarAviones(aerolinea,jobject);
		
		//Rutas
		salvarRutas(aerolinea,jobject);
		
		//Vuelos
		salvarVuelos(aerolinea,jobject);
		
		// Escribir la estructura JSON en un archivo
        PrintWriter pw;
		try {
			pw = new PrintWriter( archivo );
	        jobject.write( pw, 2, 0 );
	        pw.close( );
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
    }
    
    
    private void cargarAviones(Aerolinea aerolinea, JSONArray jAviones)throws AvionRepetidoException
    {
    	int numAviones =jAviones.length();
    	for (int i=0; i<numAviones;i++) {
    		JSONObject avion = jAviones.getJSONObject( i );
    		String nombreAvion = avion.getString(NOMBRE_AVION);
    		int capacidad = avion.getInt(CAPCIDAD_AVION);
    		Avion nuevoAvion = new Avion(nombreAvion, capacidad);
    		
    		if (!aerolinea.getAviones().contains(nuevoAvion))
    			aerolinea.agregarAvion(nuevoAvion);
    		else
    			throw new AvionRepetidoException(nuevoAvion);	
    	} 	
    }
    
    private void salvarAviones(Aerolinea aerolinea, JSONObject jobject)
    {
    	JSONArray jAviones = new JSONArray( );
    	for (Avion a:aerolinea.getAviones()) {
    		String nombreAvion = a.getNombre();
    		int capacidad = a.getCapacidad();
    		
    		JSONObject jAvion = new JSONObject( );
    		jAvion.put( NOMBRE_AVION, nombreAvion );
    		jAvion.put( CAPCIDAD_AVION, capacidad );
    		jAviones.put( jAvion );
    	}
    	jobject.put("aviones",jAviones);
    }
    
    
    
    
    
    private void cargarRutas(Aerolinea aerolinea, JSONArray jRutas)throws RutaRepetidaException
    {
    	int numRutas =jRutas.length();
    	for (int i=0; i<numRutas;i++) {
    		JSONObject ruta = jRutas.getJSONObject( i );
    		
    		String codigoRuta = ruta.getString(CODIGO_RUTA);
    		String horaLlegada = ruta.getString(RUTA_HLLEGADA);
    		String horaSalida = ruta.getString(RUTA_HSALIDA);
    		
    		
    		//Aeopuerto Origen
    		String ciudadAeropuertoO = ruta.getString(AEROPUERTOO_CIUDAD);
    		String codigoAeropuertoO = ruta.getString(AEROPUERTOO_CODIGO);
    		int latitudAeropuertoO = ruta.getInt(AEROPUERTOO_LATITUD);
    		int longitudAeropuertoO = ruta.getInt(AEROPUERTOO_LONGITUD);
    		String nombreAeropuertoO = ruta.getString(AEROPUERTOO_NOMBRE);

    		
    		Aeropuerto aeropuertoOrigen= new Aeropuerto(nombreAeropuertoO, codigoAeropuertoO, ciudadAeropuertoO, latitudAeropuertoO,longitudAeropuertoO);
    		
    		//Aeropuerto Destino
    		String ciudadAeropuertoD = ruta.getString(AEROPUERTOD_CIUDAD);
    		String codigoAeropuertoD = ruta.getString(AEROPUERTOD_CODIGO);
    		int latitudAeropuertoD = ruta.getInt(AEROPUERTOD_LATITUD);
    		int longitudAeropuertoD = ruta.getInt(AEROPUERTOD_LONGITUD);
    		String nombreAeropuertoD = ruta.getString(AEROPUERTOD_NOMBRE);

    		
    		Aeropuerto aeropuertoDestino= new Aeropuerto(nombreAeropuertoD, codigoAeropuertoD, ciudadAeropuertoD, latitudAeropuertoD,longitudAeropuertoD);

    		
    		Ruta nuevaRuta = new Ruta(aeropuertoOrigen,aeropuertoDestino, horaSalida,horaLlegada,codigoRuta);

    		
    		if (aerolinea.getRuta(codigoRuta)==null)
    			aerolinea.agregarRuta(nuevaRuta);
    		else
    			throw new RutaRepetidaException(nuevaRuta.getCodigoRuta());	
    	} 	
    }
    
    
    private void salvarRutas(Aerolinea aerolinea, JSONObject jobject)
    {
    	JSONArray jRutas = new JSONArray( );
    	for (Ruta r:aerolinea.getRutas()) {
    		
    		JSONObject jRuta = new JSONObject( );
    		jRuta.put( CODIGO_RUTA, r.getCodigoRuta());
    		jRuta.put( RUTA_HLLEGADA, r.getHoraLlegada() );
    		jRuta.put( RUTA_HSALIDA, r.getHoraSalida() );
    		
    		jRuta.put( AEROPUERTOO_CIUDAD, r.getOrigen().getNombreCiudad());
    		jRuta.put( AEROPUERTOO_CODIGO, r.getOrigen().getCodigo() );
    		jRuta.put( AEROPUERTOO_LATITUD, r.getOrigen().getLatitud() );
    		jRuta.put( AEROPUERTOO_LONGITUD, r.getOrigen().getLongitud());
    		jRuta.put( AEROPUERTOO_NOMBRE,  r.getOrigen().getNombre() );
    		
    		jRuta.put( AEROPUERTOD_CIUDAD, r.getDestino().getNombreCiudad());
    		jRuta.put( AEROPUERTOD_CODIGO, r.getDestino().getCodigo() );
    		jRuta.put( AEROPUERTOD_LATITUD, r.getDestino().getLatitud() );
    		jRuta.put( AEROPUERTOD_LONGITUD, r.getDestino().getLongitud());
    		jRuta.put( AEROPUERTOD_NOMBRE,  r.getDestino().getNombre() );

    		
    		jRutas.put( jRuta );
    	}
    	jobject.put("aviones",jRutas);
    	
    }  
    
	private void cargarVuelos(Aerolinea aerolinea, JSONArray jVuelos)throws Exception,VueloRepetidoException
    {
    	int numVuelos =jVuelos.length();
    	for (int i=0; i<numVuelos;i++) {
    		JSONObject vuelo = jVuelos.getJSONObject( i );
    		String fecha = vuelo.getString(FECHA);
    		String codigoRuta = vuelo.getString(CODIGO_RUTA);
    		String nombreAvion= vuelo.getString(NOMBRE_AVION);
 		
    		if (aerolinea.getVuelo(codigoRuta, fecha)==null)
    			aerolinea.programarVuelo(fecha, codigoRuta, nombreAvion);
    		else
    			throw new VueloRepetidoException(fecha,codigoRuta);	
    	} 	
    }
    
	private void salvarVuelos(Aerolinea aerolinea, JSONObject jobject)
    {
    	JSONArray jVuelos = new JSONArray( );
    	for (Vuelo v:aerolinea.getVuelos()) {
    		String fecha = v.getFecha();
    		String codigoRuta = v.getRuta().getCodigoRuta();
    		String nombreAvion = v.getAvion().getNombre();
    		
    		JSONObject jVuelo = new JSONObject( );
    		jVuelo.put( NOMBRE_AVION, nombreAvion );
    		jVuelo.put( CODIGO_RUTA, codigoRuta );
    		jVuelo.put(FECHA, fecha);
    		jVuelos.put( jVuelo );
    	}
    	jobject.put("vuelos",jVuelos);
    }
    
    
      
    
    
    
    
    
    
    
    
    
    
    
}

