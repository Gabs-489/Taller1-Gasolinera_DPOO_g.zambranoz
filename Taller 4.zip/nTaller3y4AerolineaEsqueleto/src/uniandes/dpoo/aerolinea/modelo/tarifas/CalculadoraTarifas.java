package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas {
	
	public static double IMPUESTO=0.28;
	
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) {
		//Falta
		int costo_descuento=0;
		double p_descuento= calcularPorcentajeDescuento(cliente);
		int costo_b = calcularCostoBase(vuelo, cliente);
		if (p_descuento!=0) {
			costo_descuento = costo_b - (int) (costo_b * p_descuento);	
		}
		else {
			costo_descuento=calcularCostoBase(vuelo, cliente);
		}
		
		int val_final = costo_descuento - calcularValorImpuestos(costo_descuento);
		return val_final;
	}
	
	protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);
	
	protected abstract double calcularPorcentajeDescuento(Cliente cliente);
	
	protected int calcularDistanciaVuelo(Ruta ruta) {
		Aeropuerto a1= ruta.getOrigen();
		Aeropuerto a2=ruta.getDestino();
		
		int kilom=Aeropuerto.calcularDistancia(a1, a2);
		
		return kilom;	
		}
	
	protected int calcularValorImpuestos(int costoBase) {
		return (int) (costoBase * IMPUESTO);
	}
}
