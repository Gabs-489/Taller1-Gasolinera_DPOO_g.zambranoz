package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.GeneradorTiquetes;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {
	
	private String fecha;
	private Ruta ruta;
	private Avion avion;
	private Map<String, Tiquete> tiquetes;
	
	public Vuelo(Ruta ruta, String fecha, Avion avion) {
		this.fecha=fecha;
		this.ruta=ruta;
		this.avion=avion;
		this.tiquetes=new HashMap<String, Tiquete>( );			
	}
	
	public Ruta getRuta(){
		return this.ruta;
	}
	
	public String getFecha(){
		return fecha;
	}
	
	public Avion getAvion(){
		return this.avion;
	}
	
	public Collection<Tiquete> getTiquetes(){
		return this.tiquetes.values();
	}
	
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) {
		int valor_total=0;
		int precio = calculadora.calcularTarifa(this, cliente);
		valor_total=precio*cantidad;	
		
		//Añadir tiquetes a clientes y al vuelo
		for (int i=0;i<=cantidad;i++) {
			Tiquete t= GeneradorTiquetes.generarTiquete(this, cliente, precio);
			cliente.agregarTiquete(t);
			tiquetes.put(t.getCodigo(), t);
		}
		
		return valor_total;
	}
	
	public boolean equals(Object obj) {
		if (obj.equals(this)) 
			return true;
		else
			return false;
	}
}
