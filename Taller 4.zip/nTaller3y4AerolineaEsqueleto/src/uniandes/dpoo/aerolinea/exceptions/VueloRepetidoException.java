package uniandes.dpoo.aerolinea.exceptions;

@SuppressWarnings("serial")
public class VueloRepetidoException extends Exception {
	private String codigo;
	private String fecha;
	
    public VueloRepetidoException(String fechaN, String codigoN )
    {
        super( );
        this.fecha=fechaN;
        this.codigo=codigoN;
        
    }

    @Override
    public String getMessage( )
    {
        return "El vuelo con el codigo de ruta" + codigo + " en la fecha " + fecha + " esta repetido.";
    }
}
