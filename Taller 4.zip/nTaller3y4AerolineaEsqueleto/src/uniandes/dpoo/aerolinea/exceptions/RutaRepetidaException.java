package uniandes.dpoo.aerolinea.exceptions;


public class RutaRepetidaException extends Exception {
	
	@SuppressWarnings("serial")
		private String codigoRuta;

	    public RutaRepetidaException(String codigo) {
	    	super( );
	        this.codigoRuta=codigo;  
		}

		@Override
	    public String getMessage( )
	    {
	        return "La ruta con el codigo " + codigoRuta + " esta repetida.";
	    }
	}

