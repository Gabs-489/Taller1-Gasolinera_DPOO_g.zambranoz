package uniandes.dpoo.aerolinea.exceptions;

import uniandes.dpoo.aerolinea.modelo.Avion;

@SuppressWarnings("serial")
public class AvionRepetidoException extends Exception {
	private String nombre;
	private int capacidad;
	
    public AvionRepetidoException(Avion avion )
    {
        super( );
        this.nombre=avion.getNombre();
        this.capacidad=avion.getCapacidad();
        
    }

    @Override
    public String getMessage( )
    {
        return "El avion " + nombre + " con capacidad de " + capacidad + " esta repetido.";
    }
}
