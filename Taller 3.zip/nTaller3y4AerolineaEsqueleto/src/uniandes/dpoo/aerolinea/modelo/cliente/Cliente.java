package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.ArrayList;
import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente {
	private List<Tiquete> tiquetesSinUsar;
	private List<Tiquete> tiquetesUsados;
	
	
	public Cliente() {
		this.tiquetesSinUsar=new ArrayList<Tiquete>();
		this.tiquetesUsados=new ArrayList<Tiquete>();
		
	}
	
	public abstract String getTipoCliente();
	
	public abstract String getIdentificador();
	
	public void agregarTiquete(Tiquete tiquete) {
		this.tiquetesSinUsar.add(tiquete);
	}
	
	public int calcularValorTotalTiquetes() {
		int suma_total=0;
		for(Tiquete t:tiquetesSinUsar) {
			int tarifa=t.getTarifa();
			suma_total+=tarifa;
		}
		for(Tiquete t:tiquetesUsados) {
			int tarifa=t.getTarifa();
			suma_total+=tarifa;
		}
		return suma_total;
		
	}
	
	public void usarTiquetes(Vuelo vuelo) {
		for (Tiquete t:vuelo.getTiquetes()) {
			this.tiquetesUsados.add(t);
		}
	}
}
